<?php 

$ini = $this->session->userdata('datalog');
 echo $ini['sekolah'].'<br>';
 echo $ini['kasek'].'<br>';
  echo $ini['bendahara'].'<br>';
   echo $ini['spp'].'<br>';
    echo $ini['tapel'].'<br>';
?>