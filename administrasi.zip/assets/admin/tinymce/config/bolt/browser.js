configure({
  configs: [
    './test.js'
  ]
})
